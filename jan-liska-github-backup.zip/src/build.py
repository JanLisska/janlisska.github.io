from pathlib import Path
import json,base64

source=Path(__file__).resolve().parent
root=source.parent
html=(source/'shell.html').read_text()
font_styles=''
for file,family,weight,style in [('SpaceGrotesk.woff','JL Grotesk','300 700','normal'),('BarlowCondensed-SemiBold.woff','JL Condensed','600','normal'),('EBGaramond-Italic.woff','JL Serif','400 800','italic')]:
    encoded=base64.b64encode((source/'fonts'/file).read_bytes()).decode()
    font_styles+="@font-face{font-family:'"+family+"';font-weight:"+weight+";font-style:"+style+";font-display:swap;src:url(data:font/woff;base64,"+encoded+") format('woff')}\n"
licenses='\n'.join(line.rstrip() for file in sorted((source/'fonts').glob('*OFL.txt')) for line in file.read_text().splitlines())
font_styles+='/* Embedded font licenses: SIL Open Font License 1.1.\n'+licenses.replace('*/','* /')+'\n*/\n'
html=html.replace('/*STYLES*/',font_styles+(source/'styles.css').read_text()+'\n'+(source/'type-study.css').read_text()+'\n'+(source/'opening.css').read_text()+'\n'+(source/'presentation.css').read_text())
html=html.replace('<!--DIALOGS-->',(source/'dialogs.html').read_text())
scripts='<script>window.JL_PREVIEW_IMAGES='+json.dumps(json.loads((source/'demo-images.json').read_text()),separators=(',',':'))+';</script>\n'
for file in ['archive-editor.js','app.js','type-study.js','opening.js']:
    scripts+='<script>\n'+(source/file).read_text()+'\n</script>\n'
html=html.replace('<!--SCRIPTS-->',scripts)
assert '<!--' not in html
for file in ['index.html','jan-liska-portfolio-acid-index-12.html']:
    (root/'dist'/file).write_text(html)
print(f'Built Acid Index 12: {len(html.encode()):,} bytes; self-contained HTML.')
