/* A short first-visit entrance. The flag survives refreshes in the same tab. */
(() => {
 'use strict';
 const key='jan-liska-opening-seen-v1',body=document.body,reduced=matchMedia('(prefers-reduced-motion: reduce)');
 let seen=false;
 try{seen=sessionStorage.getItem(key)==='1'}catch{}
 const markSeen=()=>{try{sessionStorage.setItem(key,'1')}catch{}};
 const shouldPlay=!seen&&body.dataset.view==='projects'&&!reduced.matches&&!body.classList.contains('motion-off')&&scrollY<30;
 if(!shouldPlay){markSeen();body.dataset.opening='skipped';return;}
 let timer=0,finished=false,started=false,visible=!('IntersectionObserver' in window),observer=null;
 body.dataset.opening='waiting';
 function start(){if(started||finished||document.hidden||!visible)return;started=true;markSeen();body.dataset.opening='playing';document.dispatchEvent(new CustomEvent('jl:opening-start'));observer?.disconnect();timer=setTimeout(finish,1180)}
 function finish(){if(finished)return;finished=true;markSeen();clearTimeout(timer);observer?.disconnect();body.dataset.opening='done';document.dispatchEvent(new CustomEvent('jl:opening-end'));}
 if('IntersectionObserver' in window){observer=new IntersectionObserver(entries=>{visible=entries.some(entry=>entry.isIntersecting);start()},{threshold:.02});observer.observe(document.getElementById('kineticHeading'))}
 document.addEventListener('jl:view-change',finish,{once:true});
 document.addEventListener('pointerdown',finish,{once:true,passive:true});
 document.addEventListener('keydown',finish,{once:true});
 addEventListener('scroll',()=>{if(scrollY>30)finish()},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(started&&document.hidden)finish();else start()});
 reduced.addEventListener('change',()=>{if(reduced.matches)finish()});
 document.getElementById('motionToggle').addEventListener('click',()=>{if(body.classList.contains('motion-off'))finish()});
 start();
})();
