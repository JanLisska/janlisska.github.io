/* Public navigation uses the existing Projects collections directly. */
(() => {
 'use strict';
 const api=window.JLArchive,$=id=>document.getElementById(id),reduce=matchMedia('(prefers-reduced-motion: reduce)');
 const defaults={email:'liska749@gmail.com',hero:'Photographic work, one project at a time.',statement:'Photographs as a way of paying attention. To people, to places, to what might otherwise pass unnoticed.',bio:'Personal work, commissions and collaborations.\n\nFor a project, a collaboration or an idea you’d like to bring to life, get in touch.',social:''};
 let route={view:'projects'},syncing=false,rendering=false,cardToken=0,lightboxRows=[],photoIndex=0,photoRequest=0;
 let layoutToolsOpen=true;
 const scrollPositions=new Map(),lightbox=$('lightbox');
 const state=()=>api.getState(),profile=()=>({...defaults,...state().presentation.profile});
 const ideas=()=>Array.isArray(state().presentation.ideas)?state().presentation.ideas:[];
 const projectKey=()=>state().presentation.projectSectionKey||'projects';
 const clubName='Činoherní klub';
 const isClub=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'').includes('cinoherniklub');
 function clubLocation(){
  const s=state(),candidates=[];
  for(const [section,group] of Object.entries(s.allData)){
   const label=s.sections.find(entry=>entry[0]===section)?.[1]||section;
   if(isClub(label)||isClub(section)){const entries=Object.entries(group),name=entries.find(([key,items])=>items.some(i=>i.type==='image'))?.[0]||entries[0]?.[0];if(name)candidates.push({section,name,grouped:true,items:entries.flatMap(([,items])=>items)});}
   for(const [name,items] of Object.entries(group))if(isClub(name))candidates.push({section,name,grouped:false,items});
  }
  return candidates.sort((a,b)=>b.items.filter(i=>i.type==='image').length-a.items.filter(i=>i.type==='image').length||Number(b.grouped)-Number(a.grouped))[0]||null;
 }
 const isClubLocation=(section,name)=>{const club=clubLocation();return club?.section===section&&(club.grouped||club.name===name)};
 function node(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
 function url(value){try{const u=new URL(value);return ['https:','http:'].includes(u.protocol)?u.href:''}catch{return ''}}
 function emailHref(subject='',body=''){return'mailto:'+profile().email+(subject?'?subject='+encodeURIComponent(subject)+'&body='+encodeURIComponent(body):'');}
 function setMeta(patch){api.setPresentation({...state().presentation,...patch});}
 const menuDefaults={projects:'Projects',archive:'Archive',ideas:'Ideas',info:'Info / contact'};
 const menuText=()=>state().presentation.menuText||{};
 const menuLabel=key=>menuText().labels?.[key]||menuDefaults[key];
 function projectLabel(name){
  const existing=menuText().projects;
  return (Array.isArray(existing)?existing.find(([key])=>key===name)?.[1]:null)||name;
 }
 function showMenuEditor(){
  if(!state().edit)return;
  $('menuProjectsTitle').value=menuText().title||menuDefaults.projects;
  $('menuIntro').value=profile().hero;
  fillLabelFields($('menuLabelFields'),Object.entries(menuDefaults),menuLabel);
  fillLabelFields($('projectLabelFields'),projects().map(p=>[p.name,p.name]),projectLabel);
  $('menuDialog').showModal();
 }
 function fillLabelFields(container,entries,valueFor){
  container.replaceChildren();
  for(const [key,labelText] of entries){
   const label=node('label','',labelText);
   const input=node('input');input.type='text';input.dataset.labelKey=key;input.maxLength=80;input.value=valueFor(key);
   label.append(input);container.append(label);
  }
 }
 $('editMenu').onclick=showMenuEditor;
 $('editHomeText').onclick=showMenuEditor;
 $('menuForm').onsubmit=event=>{
  event.preventDefault();
  if(!state().edit)return;
  const read=id=>Array.from($(id).querySelectorAll('input'),input=>[input.dataset.labelKey,input.value.trim()]);
  const title=$('menuProjectsTitle').value.trim()||menuDefaults.projects;
  const intro=$('menuIntro').value.trim();
  $('menuDialog').close();
  setMeta({
   menuText:{...menuText(),title,labels:Object.fromEntries(read('menuLabelFields')),projects:read('projectLabelFields')},
   profile:{...state().presentation.profile,hero:intro}
  });
  api.notify('Menu and homepage text saved.');
 };
 function adjustLandingSpace(change){
  if(!state().edit)return;
  setMeta({landingSpace:Math.max(0,(Number(state().presentation.landingSpace)||0)+change)});
 }
 $('landingAddSpace').onclick=()=>adjustLandingSpace(600);
 $('landingLessSpace').onclick=()=>adjustLandingSpace(-300);
 function browseProjects(){
  const index=$('projectIndexLabel');
  index.focus({preventScroll:true});
  index.scrollIntoView({behavior:reduce.matches||document.body.classList.contains('motion-off')?'instant':'smooth',block:'start'});
 }
 $('browseProjects').onclick=browseProjects;
 function renderLayoutTools(){
  const available=state().edit&&['project','archive','club'].includes(route.view);
  $('toolbar').classList.toggle('hidden',!available||!layoutToolsOpen);
  $('showLayoutTools').setAttribute('aria-expanded',String(available&&layoutToolsOpen));
  $('showLayoutTools').textContent=layoutToolsOpen?'Hide layout tools':'Show layout tools';
 }
 $('showLayoutTools').onclick=()=>{layoutToolsOpen=!layoutToolsOpen;renderLayoutTools()};
 function decorate(){
  for(const el of document.querySelectorAll('.text-link,.contact-top,.site-sidebar a,.contact-line a,.contact-email,.contact-choice a,.lightbox-arrows button,.card-arrow,.collection-pager a,.text-link span[aria-hidden],.contact-top span[aria-hidden]'))for(const child of [...el.childNodes]){
   if(child.nodeType!==Node.TEXT_NODE||!/[↗←→]/.test(child.textContent))continue;
   const fragment=document.createDocumentFragment();for(const part of child.textContent.split(/([↗←→])/)){if(!/[↗←→]/.test(part)){fragment.append(document.createTextNode(part));continue}const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 16 16');svg.setAttribute('class','icon-arrow');svg.setAttribute('aria-hidden','true');const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d',part==='↗'?'M3 13 13 3M3 3h10v10':part==='←'?'M14 8H2m5-5L2 8l5 5':'M2 8h12M9 3l5 5-5 5');svg.append(path);fragment.append(svg)}child.replaceWith(fragment);
  }
 }
 function projects(){const groups=state().allData[projectKey()]||{};const entries=Object.entries(groups).filter(([name,items])=>!isClub(name)&&!(name==='Selected projects'&&!items.length)).map(([name,items])=>({name,items,images:items.filter(i=>i.type==='image')}));const club=clubLocation();if(club)entries.splice(Math.max(0,entries.findIndex(entry=>entry.name.toLowerCase()==='bts')+1),0,{name:clubName,items:club.items,images:club.items.filter(i=>i.type==='image'),club:true});return entries;}
 function allPhotos(){const s=state(),photos=[];for(const [key,label] of s.sections)for(const [collection,items] of Object.entries(s.allData[key]||{}))for(const item of items)if(item.type==='image')photos.push({item,section:key,label,collection});return photos;}
 const projectHash=name=>'#projects/'+encodeURIComponent(name);
 function routeHash(r){return r.view==='club'?'#cinoherni-klub'+(r.name?'/'+encodeURIComponent(r.name):''):r.view==='project'?projectHash(r.name):r.view==='archive'&&r.section&&r.name?'#archive/'+encodeURIComponent(r.section)+'/'+encodeURIComponent(r.name):'#'+r.view;}
 function parseHash(hash){
  const raw=hash.replace(/^#/,'');try{
   if(raw==='cinoherni-klub'||raw==='club')return{view:'club'};
   if(raw.startsWith('cinoherni-klub/'))return{view:'club',name:decodeURIComponent(raw.slice(15))};
   if(raw.startsWith('projects/'))return{view:'project',name:decodeURIComponent(raw.slice(9))};
   if(raw.startsWith('archive/')){const bits=raw.slice(8).split('/');return{view:'archive',section:decodeURIComponent(bits[0]),name:decodeURIComponent(bits.slice(1).join('/'))};}
  }catch{return{view:'projects'}}
  return{view:['archive','ideas','info'].includes(raw)?raw:'projects'};
 }
 function renderNavigation(){
  const nav=$('projectNav'),entries=projects();nav.replaceChildren();$('projectTotal').textContent=String(entries.length).padStart(2,'0');
  $('projectsMenuLabel').textContent=menuLabel('projects');
  for(const link of document.querySelectorAll('.secondary-nav [data-go]'))link.textContent=menuLabel(link.dataset.go);
  $('backToProjects').textContent='Back to '+menuLabel('projects');
  entries.forEach((p,index)=>{const link=node('a','project-nav-link');link.href=p.club?'#cinoherni-klub':projectHash(p.name);if(p.club)link.dataset.go='club';else link.dataset.project=p.name;link.append(node('span','nav-number',String(index+1).padStart(2,'0')),node('span','nav-label',projectLabel(p.name)),node('span','nav-count',p.images.length));if(p.club?route.view==='club':route.view==='project'&&route.name===p.name)link.setAttribute('aria-current','page');nav.append(link)});
  if(state().edit){const add=node('button','text-link','Add project +');add.type='button';add.onclick=addProject;nav.append(add)}
  document.querySelectorAll('#siteNav [data-go]').forEach(a=>{if(a.dataset.go===route.view)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});
 }
 function renderProjectIndex(){
  const grid=$('projectGrid'),entries=projects(),token=++cardToken;grid.replaceChildren();
  $('projectIndexCount').textContent=String(entries.length).padStart(2,'0')+' folders / '+String(entries.reduce((n,p)=>n+p.images.length,0)).padStart(2,'0')+' photographs';
  if(!entries.length){const blank=node('div','project-grid-empty','A place for the next project.');blank.append(node('p','','Project folders will appear here as they are added.'));grid.append(blank);return;}
  for(const p of entries){
   const card=node('a','project-card');card.href=p.club?'#cinoherni-klub':projectHash(p.name);if(p.club)card.dataset.go='club';else card.dataset.project=p.name;card.setAttribute('aria-label',p.name+' — '+p.images.length+' photographs');const cover=node('div','project-cover');
   if(p.images.length){const img=new Image();img.alt=p.images[0].caption||p.name;img.loading='lazy';img.decoding='async';cover.append(img);api.imageSource(p.images[0].src).then(src=>{if(cardToken!==token)return;if(src)img.src=src;else showEmptyCover()}).catch(showEmptyCover);img.onerror=showEmptyCover;}
   else showEmptyCover();
   function showEmptyCover(){cover.replaceChildren();cover.classList.add('empty');const name=p.name.length>16?p.name.slice(0,14)+'…':p.name;cover.append(node('span',p.name.length>10?'empty-monogram long-name':'empty-monogram',name),node('span','empty-note',p.images.length?'Preview unavailable':'No photographs yet'));}
   const label=node('div','project-card-label');label.append(node('h2','',p.name),node('span','card-count',String(p.images.length).padStart(2,'0')+' photographs'));const arrow=node('span','card-arrow','↗');arrow.setAttribute('aria-hidden','true');label.append(arrow);card.append(cover,label);grid.append(card);
  }
 }
 function renderProfile(){
  const p=profile(),title=menuText().title||menuDefaults.projects;
  if($('projectsTitleText').textContent!==title){
   $('projectsTitleText').textContent=title;
   $('projectsTitle').querySelector('.acid-period').hidden=/[.!?…]$/.test(title);
   document.dispatchEvent(new Event('jl:project-title-change'));
  }
  if(route.view==='projects')document.title='Jan Liška — '+title;
  const space=Math.max(0,Number(state().presentation.landingSpace)||0);
  $('landingIntro').style.setProperty('--landing-space',space+'px');
  $('landingSpaceValue').textContent=space?space+' px extra':'';
  $('landingLessSpace').disabled=!space;
  document.querySelector('.projects-copy > p').textContent=p.hero;$('profileStatement').textContent=p.statement;$('profileBio').textContent=p.bio;$('profileEmail').textContent=p.email+' ↗';$('profileEmail').href=emailHref();
  document.querySelectorAll('[data-contact]').forEach(a=>a.href=emailHref(a.dataset.contact==='ideas'?'An idea to explore':''));
  const sidebar=document.querySelector('.sidebar-foot a');sidebar.textContent=p.email+' ↗';sidebar.href=emailHref();
  const social=$('profileSocial');social.hidden=!url(p.social);if(!social.hidden){social.href=url(p.social);social.textContent=new URL(p.social).hostname.replace('www.','')+' ↗';}
 }
 function renderIdeas(){
  const list=$('ideaList'),entries=ideas();list.replaceChildren();$('ideaCount').textContent=String(entries.length).padStart(2,'0')+' '+(entries.length===1?'open idea':'open ideas');
  if(!entries.length){const blank=node('div','idea-empty');const mark=node('div','empty-mark','( … )');mark.setAttribute('aria-hidden','true');const copy=node('div');copy.append(node('h2','','A little room for the next thing.'),node('p','','No ideas have been published here yet. The door is open for a conversation, a collaboration, or something unexpected.'));if(state().edit){const b=node('button','text-link','Add your first idea +');b.type='button';b.onclick=()=>editIdea();copy.append(b)}else{const a=node('a','text-link','Let’s talk ↗');a.href=emailHref('An idea to explore');a.onclick=e=>{e.preventDefault();contact('ideas')};copy.append(a)}blank.append(mark,copy);list.append(blank);return;}
  entries.forEach((idea,index)=>{
   const card=node('article','idea-card'),main=node('div'),aside=node('div','idea-aside');card.append(node('span','idea-number',String(index+1).padStart(2,'0')));
   const status=node('span','idea-status',({Seed:'An initial idea',Seeking:'Looking for support',Making:'In the making'})[idea.stage]||'An initial idea');status.dataset.stage=idea.stage;
   main.append(node('h2','',idea.title),status);if(idea.format)main.append(node('p','eyebrow',idea.format));main.append(node('p','',idea.description));
   aside.append(node('div','eyebrow','What would help'),node('p','',idea.need||'A conversation, a collaboration, a way forward.'));
   const support=node('button','text-link','Help it happen ↗');support.type='button';support.onclick=()=>contact('support',idea);aside.append(support);
   if(state().edit){const controls=node('div','idea-actions');const edit=node('button','','Edit idea');edit.type='button';edit.onclick=()=>editIdea(idea);const del=node('button','','Remove');del.type='button';del.onclick=()=>{if(confirm('Remove this idea?'))setMeta({ideas:ideas().filter(i=>i.id!==idea.id)})};controls.append(edit,del);aside.append(controls)}
   card.append(main,aside);list.append(card);
  });
 }

 function renderCollection(){
  const s=state(),canvas=$('canvas'),current=s.allData[s.section]?.[s.branch]||[];
  document.body.classList.toggle('club-grouped',route.view==='club'&&!!clubLocation()?.grouped);
  if(route.view==='club'&&!s.pageText[s.section+'::'+s.branch]?.[1])document.querySelector('.intro h1').innerText=clubLocation()?.grouped?s.branch:clubName;
  $('collectionCount').textContent=current.filter(i=>i.type==='image').length+' photographs';
  $('playCollection').hidden=s.edit||!['project','club'].includes(route.view)||!current.some(i=>i.type==='image');
  document.querySelectorAll('#sections .nav-unit').forEach(wrap=>{wrap.hidden=!s.edit&&wrap.dataset.section===projectKey()});
  canvas.querySelector('.archive-empty')?.remove();
  canvas.querySelectorAll('.item').forEach(el=>{
   const item=current.find(i=>i.id===Number(el.dataset.id));if(item?.type!=='image')return;
   const img=el.querySelector('img');if(img){img.onerror=()=>{if(img.getAttribute('src'))el.classList.add('image-missing')};img.onload=()=>el.classList.remove('image-missing');}
   if(!s.edit){el.tabIndex=0;el.setAttribute('role','button');el.setAttribute('aria-label','View photograph: '+(item.caption||s.branch));}
  });
  if(!current.length&&!s.edit){const empty=node('div','archive-empty','No photographs yet.');empty.append(node('p','',route.view==='project'?'This project folder is ready for its photographs.':'Explore another collection in the archive.'));canvas.append(empty);canvas.style.height='260px';}
  const pager=$('collectionPager');pager.replaceChildren();pager.hidden=route.view!=='project';
  if(route.view==='project'){const entries=projects(),index=entries.findIndex(p=>p.name===s.branch);if(index>0){const prev=node('a','','← '+entries[index-1].name);prev.href=entries[index-1].club?'#cinoherni-klub':projectHash(entries[index-1].name);if(entries[index-1].club)prev.dataset.go='club';else prev.dataset.project=entries[index-1].name;pager.append(prev)}else pager.append(node('span'));if(index>=0&&index<entries.length-1){const next=node('a','',entries[index+1].name+' →');next.href=entries[index+1].club?'#cinoherni-klub':projectHash(entries[index+1].name);if(entries[index+1].club)next.dataset.go='club';else next.dataset.project=entries[index+1].name;pager.append(next)}}
  $('renameProject').hidden=route.view!=='project';
 }
 function renderAll(){
  if(rendering)return;rendering=true;try{
   api.ensureProjectCollections();api.ensureClubCollection();const s=state();document.body.dataset.editing=String(s.edit);$('mode').textContent=s.edit?'Done editing':'Edit website';
   renderNavigation();renderProjectIndex();renderIdeas();renderProfile();renderCollection();
   renderLayoutTools();decorate();
  }finally{rendering=false}
 }
 function navigate(next,{historyMode='push',scroll=true,focus=false,index=false}={}){
  if(typeof next==='string')next={view:next};if(next.view==='work')next={view:'projects'};
  const previousHash=routeHash(route);scrollPositions.set(previousHash,scrollY);
  if(lightbox.open)lightbox.close();
  if(next.view==='project'&&isClub(next.name)&&clubLocation())next={view:'club'};
  if(next.view==='club'){const club=clubLocation();if(club){const name=club.grouped&&next.name&&state().allData[club.section]?.[next.name]?next.name:club.name;next={view:'club',section:club.section,name};}else next={view:'projects'};}
  if(next.view==='project'&&!state().allData[projectKey()]?.[next.name])next={view:'projects'};
  if(next.view==='archive'){
   const s=state();const key=next.section&&s.allData[next.section]&&next.section!==projectKey()?next.section:(s.section!==projectKey()&&s.allData[s.section]&&!isClubLocation(s.section,s.branch)?s.section:(s.allData.archive?'archive':Object.keys(s.allData).find(k=>k!==projectKey())));
   const branch=next.name&&s.allData[key]?.[next.name]?next.name:(s.section===key&&s.allData[key]?.[s.branch]&&!isClubLocation(key,s.branch)?s.branch:(Object.keys(s.allData[key]||{}).find(name=>!isClubLocation(key,name))||Object.keys(s.allData[key]||{})[0]));
   if(key&&branch)next={view:'archive',section:key,name:branch};else next={view:'projects'};
  }
  syncing=true;try{if(next.view==='project')api.showCollection(projectKey(),next.name);if(['archive','club'].includes(next.view))api.showCollection(next.section,next.name)}finally{syncing=false}
  route=next;document.body.dataset.view=route.view;
  const display=['project','archive','club'].includes(route.view)?'collection':route.view;
  $('landingIntro').hidden=display!=='projects';
  document.querySelectorAll('section[data-view]').forEach(el=>el.hidden=el.dataset.view!==display);
  const hash=routeHash(route);if(historyMode==='push'&&location.hash!==hash)history.pushState(null,'',hash);else if(historyMode==='initial')history.replaceState(null,'',hash);
  renderAll();
  if(index&&display==='projects')browseProjects();
  else if(scroll)window.scrollTo({top:historyMode==='pop'?(scrollPositions.get(hash)||0):0,behavior:'instant'});
  document.title='Jan Liška — '+(route.view==='club'?clubName:route.view==='project'?route.name:({projects:menuText().title||menuDefaults.projects,archive:'Archive',ideas:'Ideas',info:'Information'})[route.view]);
  if(focus&&!index){const heading=display==='projects'?$('projectsTitle'):document.querySelector('section[data-view="'+display+'"] h1');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true})}}
  document.dispatchEvent(new CustomEvent('jl:view-change',{detail:{view:route.view}}));
  if(!state().edit&&['project','club'].includes(route.view))playCurrentCollection();
 }
 // Once reached, the navigation stays available for the rest of the visit.
 if('IntersectionObserver' in window){
  let reachedIndex=false;
  const sidebar=document.querySelector('.site-sidebar');
  const actions=document.querySelector('.site-header .actions');
  function updateMenu(){
   const waiting=route.view==='projects'&&!reachedIndex&&!state().edit;
   document.body.dataset.menuReveal=waiting?'waiting':'ready';
   sidebar.inert=waiting;
   actions.inert=waiting;
  }
  const observer=new IntersectionObserver(entries=>{
   if(!entries.some(entry=>entry.isIntersecting))return;
   reachedIndex=true;
   observer.disconnect();
   updateMenu();
  },{rootMargin:'0px 0px -24% 0px'});
  observer.observe($('projectIndexLabel'));
  document.addEventListener('jl:view-change',updateMenu);
  document.addEventListener('jl:archive-change',updateMenu);
 }
 function addProject(){if(!state().edit)return;$('projectForm').reset();$('projectDialog').showModal();}
 $('newProject').onclick=addProject;
 $('projectForm').onsubmit=e=>{e.preventDefault();if(!state().edit)return;const name=$('projectName').value.trim();if(!name)return;if(!api.addProject(name)){api.notify('A folder with this name already exists.');return}$('projectDialog').close();navigate({view:'project',name},{focus:true});};
 $('quickAddPhoto').onclick=()=>$('newPhotoFile').click();$('renameProject').onclick=()=>api.renameCurrentCollection();
 document.addEventListener('click',e=>{
  const project=e.target.closest('[data-project]');if(project&&!e.metaKey&&!e.ctrlKey&&!e.shiftKey){e.preventDefault();navigate({view:'project',name:project.dataset.project},{focus:true});return;}
  const go=e.target.closest('[data-go]');if(go&&!e.metaKey&&!e.ctrlKey&&!e.shiftKey&&!e.altKey){e.preventDefault();navigate({view:go.dataset.go},{focus:true,index:go.hasAttribute('data-index')});return;}
  const close=e.target.closest('[data-close]');if(close)$(close.dataset.close)?.close();
  const a=e.target.closest('[data-contact]');if(a){e.preventDefault();contact(a.dataset.contact);}
 });
 addEventListener('popstate',()=>navigate(parseHash(location.hash),{historyMode:'pop',focus:true}));
 document.addEventListener('jl:archive-change',()=>{
  if(syncing)return;
  const previous=route;
  if(['project','archive','club'].includes(route.view)){const s=state();route=isClubLocation(s.section,s.branch)?{view:'club',section:s.section,name:s.branch}:s.section===projectKey()?{view:'project',name:s.branch}:{view:'archive',section:s.section,name:s.branch};document.body.dataset.view=route.view;history.replaceState(null,'',routeHash(route));}
  renderAll();
  if(route.view==='club'&&route.name!==previous.name&&!state().edit)playCurrentCollection();
 });
 document.addEventListener('jl:presentation-change',renderAll);
 $('motionToggle').addEventListener('click',()=>document.body.classList.toggle('motion-off',$('motionToggle').getAttribute('aria-pressed')==='false'));
 // Native modal viewer, with keyboard, touch and original image proportions.
 async function showPhoto(){
  const request=++photoRequest,row=lightboxRows[photoIndex];if(!row)return;
  $('lightboxCounter').textContent=String(photoIndex+1).padStart(2,'0')+' / '+String(lightboxRows.length).padStart(2,'0');
  $('lightboxCaption').textContent=row.item.showCaption!==false?(row.item.caption||''):'';$('lightboxCollection').textContent=row.collection+' / '+row.label;
  $('previousPhoto').disabled=photoIndex===0;$('nextPhoto').disabled=photoIndex===lightboxRows.length-1;
  const img=$('lightboxImage');img.removeAttribute('src');img.alt=row.item.caption||row.collection;$('lightboxFailure').hidden=true;
  img.onerror=()=>{$('lightboxFailure').hidden=false};
  try{const src=await api.imageSource(row.item.src);if(request!==photoRequest||!lightbox.open)return;if(src)img.src=src;else $('lightboxFailure').hidden=false}catch{if(request===photoRequest&&lightbox.open)$('lightboxFailure').hidden=false}
 }
 function collectionPhotos(){
  const s=state();
  return allPhotos().filter(photo=>photo.section===s.section&&photo.collection===s.branch);
 }
 function cinemaRoute(){return ['project','club'].includes(route.view)}
 function playCurrentCollection(){openViewer(collectionPhotos(),0,true);}
 $('playCollection').onclick=playCurrentCollection;
 function openViewer(source,index,cinema=false){
  if(!source.length||lightbox.open)return;
  lightboxRows=source;photoIndex=index;
  lightbox.classList.toggle('cinema',cinema);
  $('cinemaTitle').hidden=!cinema;
  $('cinemaTitle').textContent=route.view==='club'?projectLabel(clubName):projectLabel(source[index].collection);
  $('cinemaKeys').hidden=!cinema||source.length===1;
  lightbox.showModal();
  showPhoto();
 }
 $('closeLightbox').onclick=()=>lightbox.close();$('previousPhoto').onclick=()=>{if(photoIndex>0){photoIndex--;showPhoto()}};$('nextPhoto').onclick=()=>{if(photoIndex<lightboxRows.length-1){photoIndex++;showPhoto()}};
 lightbox.addEventListener('keydown',event=>{
  const space=event.key===' '&&lightbox.classList.contains('cinema');
  const next=event.key==='ArrowRight'||(space&&!event.shiftKey);
  const previous=event.key==='ArrowLeft'||(space&&event.shiftKey);
  if(!next&&!previous)return;
  event.preventDefault();
  if(!event.repeat)$(next?'nextPhoto':'previousPhoto').click();
 });
 lightbox.addEventListener('close',()=>{
  if(lightbox.open)return;
  photoRequest++;
  $('lightboxImage').removeAttribute('src');
  if(lightbox.classList.contains('cinema')&&!$('playCollection').hidden)$('playCollection').focus({preventScroll:true});
 });
 let startX=0,startY=0;$('lightboxStage').addEventListener('touchstart',e=>{startX=e.changedTouches[0].clientX;startY=e.changedTouches[0].clientY},{passive:true});$('lightboxStage').addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;if(Math.abs(dx)>60&&Math.abs(dx)>Math.abs(dy)*1.4)(dx<0?$('nextPhoto'):$('previousPhoto')).click()},{passive:true});
 $('canvas').addEventListener('click',e=>{if(state().edit)return;const el=e.target.closest('.item');if(!el)return;const current=collectionPhotos(),index=current.findIndex(r=>r.item.id===Number(el.dataset.id));if(index>=0)openViewer(current,index,cinemaRoute())});
 $('canvas').addEventListener('keydown',e=>{if(state().edit||!['Enter',' '].includes(e.key)||!e.target.matches('.item[role=button]'))return;e.preventDefault();e.target.click()});
 // Contact stays explicit: email or a project-specific external funding page.
 function contact(kind,idea){
  const isIdea=kind==='support',p=profile();$('contactTitle').textContent=isIdea?idea.title:kind==='ideas'?'Make room for an idea.':'Have a project in mind?';$('contactKicker').textContent=isIdea?'Ideas room / help it happen':'Commissions / collaborations';
  $('contactDescription').textContent=isIdea?(idea.need||'Let’s talk about what would help this idea become real.'):kind==='ideas'?'A location, production, a collaboration, or an idea of your own. Tell me what you have in mind.':'For a commission or collaboration, tell me a little about the project, timing and what you’d like to make.';
  const subject=isIdea?'Support for “'+idea.title+'”':kind==='ideas'?'An idea to explore':'Photography enquiry';const body=isIdea?'Hi Jan,\n\nI’d like to talk about supporting “'+idea.title+'”.\n\n':'Hi Jan,\n\n';
  $('contactEmail').textContent=p.email+' ↗';$('contactEmail').href=emailHref(subject,body);$('contactWrite').href=emailHref(subject,body);const support=$('contactSupportLink');support.hidden=!isIdea||!url(idea?.supportUrl);if(!support.hidden)support.href=url(idea.supportUrl);else support.removeAttribute('href');decorate();$('contactDialog').showModal();
 }
 function editIdea(idea){if(!state().edit)return;$('ideaForm').reset();$('ideaId').value=idea?.id||'';for(const key of ['Title','Format','Description','Need','SupportUrl'])$('idea'+key).value=idea?.[key[0].toLowerCase()+key.slice(1)]||'';$('ideaStage').value=idea?.stage||'Seed';$('ideaDialog').showModal();}
 $('addIdea').onclick=()=>editIdea();
 $('ideaForm').onsubmit=e=>{e.preventDefault();if(!state().edit)return;const idea={id:$('ideaId').value||crypto.randomUUID(),title:$('ideaTitle').value.trim(),format:$('ideaFormat').value.trim(),stage:$('ideaStage').value,description:$('ideaDescription').value.trim(),need:$('ideaNeed').value.trim(),supportUrl:url($('ideaSupportUrl').value)};if(!idea.title||!idea.description)return;const existing=ideas(),index=existing.findIndex(i=>i.id===idea.id),next=existing.slice();if(index>=0)next[index]=idea;else next.push(idea);setMeta({ideas:next});$('ideaDialog').close();api.notify('Idea saved in this browser. Export a backup to keep a copy.');};
 $('editProfile').onclick=()=>{if(!state().edit)return;const p=profile();$('profileEmailInput').value=p.email;$('profileHeroInput').value=p.hero;$('profileStatementInput').value=p.statement;$('profileBioInput').value=p.bio;$('profileSocialInput').value=p.social;$('profileDialog').showModal()};
 $('profileForm').onsubmit=e=>{e.preventDefault();if(!state().edit)return;setMeta({profile:{email:$('profileEmailInput').value.trim(),hero:$('profileHeroInput').value.trim(),statement:$('profileStatementInput').value.trim(),bio:$('profileBioInput').value.trim(),social:url($('profileSocialInput').value)}});$('profileDialog').close();api.notify('Profile saved in this browser.');};

 document.addEventListener('pointerdown',e=>{const tools=document.querySelector('.studio-menu');if(tools.open&&!tools.contains(e.target))tools.open=false});
 for(const dialog of document.querySelectorAll('dialog'))dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}});
 window.JLPresentation={navigate,parseHash,projects,clubLocation,getRoute:()=>({...route})};
 api.ensureProjectCollections();api.ensureClubCollection();navigate(parseHash(location.hash),{historyMode:'initial',scroll:false});
})();
