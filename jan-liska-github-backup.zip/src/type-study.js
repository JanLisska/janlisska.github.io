/* Typography study: the vertical sine tile movement follows the sketch and
   Tiles class supplied by the user, credited there to Arjun, January 2022.
   Adapted to Canvas 2D, responsive text, bounded motion and accessible DOM type. */
(() => {
 'use strict';
 const $=id=>document.getElementById(id),api=window.JLArchive,heading=$('kineticHeading'),title=$('projectsTitle'),canvas=$('typeCanvas');
 const choices=['grotesk','condensed','elastic'];
 const notes={grotesk:'01 / Space Grotesk + gravity — move across the title to bend its rhythm.',condensed:'02 / Barlow Condensed + gravity — a narrow poster in motion.',elastic:'03 / EB Garamond Italic + gravity — an elastic title.'};
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
 class Tile{
  constructor(x,y,w,h,index){this.x=x;this.y=y;this.w=w;this.h=h;this.a=0;this.inc=((Math.imul(index+17,16807)>>>0)%997)/997;this.ySin=0;}
  move(dt,mouseX,mouseY,width,height,strength=1){
   const x=clamp(mouseX/Math.max(1,width),0,1),y=clamp(mouseY/Math.max(1,height),0,1);
   const incre=y*3;this.a=(this.a+(this.inc+incre)*clamp(dt,0,50)/(1000/60))%360;
   const amplitude=Math.min(22,Math.max(5,height*.085),(5+x*35)*.55);
   this.ySin=Math.sin(this.a*Math.PI/180)*amplitude*strength;
  }
 }
 function makeTiles(width,height){const size=Math.max(24,Math.ceil(Math.sqrt(width*height/240))),tiles=[];for(let y=0;y<height;y+=size)for(let x=0;x<width;x+=size)tiles.push(new Tile(x,y,Math.min(size,width-x),Math.min(size,height-y),tiles.length));return tiles;}
 function drawTiles(ctx,texture,width,height,tiles,dpr=1){ctx.clearRect(0,0,width,height);for(const t of tiles)ctx.drawImage(texture,t.x*dpr,t.y*dpr,t.w*dpr,t.h*dpr,t.x,t.y+t.ySin,t.w,t.h);}
 window.JLTypeStudy={Tile,makeTiles,drawTiles};
 if(!heading||!canvas||!title)return;
 let variant='grotesk',generation=0,raf=0,resizeFrame=0,lastTime=0,visible=true,texture=null,tiles=[],width=0,height=0,dpr=1,pointerX=.5,pointerY=.5,strength=.6,targetStrength=.6;
 const ctx=canvas.getContext('2d');
 function stored(){const value=api.getState().presentation.typography?.variant;return choices.includes(value)?value:'grotesk';}
 function preferred(){const requested=new URLSearchParams(location.search).get('type');return choices.includes(requested)?requested:stored();}
 function stop(){if(raf)cancelAnimationFrame(raf);raf=0;lastTime=0;}
 function allowed(){return choices.includes(variant)&&visible&&document.body.dataset.view==='projects'&&document.body.dataset.editing!=='true'&&!['waiting','playing'].includes(document.body.dataset.opening)&&!document.hidden&&!reduced.matches&&!document.body.classList.contains('motion-off')&&!document.querySelector('dialog[open]');}
 function drawStatic(){if(ctx&&texture){ctx.clearRect(0,0,width,height);ctx.drawImage(texture,0,0,width,height);}}
 function frame(time){
  raf=0;if(!allowed()||!texture){sync();return;}
  const dt=lastTime?Math.min(50,time-lastTime):1000/60;lastTime=time;strength+=(targetStrength-strength)*(1-Math.exp(-dt/150));
  for(const tile of tiles)tile.move(dt,pointerX*width,pointerY*height,width,height,strength);
  drawTiles(ctx,texture,width,height,tiles,dpr);raf=requestAnimationFrame(frame);
 }
 function sync(){
  if(!ctx||!texture||!allowed()){stop();heading.dataset.kineticReady='false';return;}
  heading.dataset.kineticReady='true';if(!raf)raf=requestAnimationFrame(frame);
 }
 async function buildTexture(){
  const token=++generation;stop();heading.dataset.kineticReady='false';
  if(!ctx||!document.fonts?.load){texture=null;return;}
  const before=getComputedStyle(title),fontRequest=before.fontStyle+' '+before.fontWeight+' '+before.fontSize+' '+before.fontFamily;
  try{await document.fonts.load(fontRequest);await document.fonts.ready;}catch{}
  if(token!==generation)return;
  const rect=heading.getBoundingClientRect();width=Math.round(rect.width);height=Math.round(rect.height);if(width<30||height<30){texture=null;return;}
  const range=document.createRange();
  range.selectNodeContents($('projectsTitleText'));
  if(range.getClientRects?.().length>1){texture=null;return;}
  dpr=Math.min(devicePixelRatio||1,1.5);canvas.width=Math.ceil(width*dpr);canvas.height=Math.ceil(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);
  texture=document.createElement('canvas');texture.width=canvas.width;texture.height=canvas.height;
  const paint=texture.getContext('2d');if(!paint){texture=null;return;}
  paint.setTransform(dpr,0,0,dpr,0,0);const style=getComputedStyle(title),size=parseFloat(style.fontSize)||140,tracking=parseFloat(style.letterSpacing)||0;
  paint.font=style.fontStyle+' '+style.fontWeight+' '+size+'px '+style.fontFamily;paint.textBaseline='alphabetic';paint.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--ink').trim()||'#171717';
  const accent=!title.querySelector('.acid-period').hidden;
  let text=$('projectsTitleText').textContent+(accent?'.':'');
  if(style.textTransform==='lowercase')text=text.toLowerCase();
  if(style.textTransform==='uppercase')text=text.toUpperCase();
  const metrics=paint.measureText(text),ascent=metrics.actualBoundingBoxAscent||size*.72,descent=metrics.actualBoundingBoxDescent||size*.2;
  const baseline=(height-ascent-descent)/2+ascent;let x=Math.max(4,size*.025);
  function paintAccent(dotX,dotWidth){
   paint.fillStyle='#e1ff46';
   paint.fillRect(dotX-size*.02,baseline-size*.23,dotWidth+size*.07,size*.29);
   paint.fillStyle='#171717';
  }
  if('letterSpacing' in paint){
   paint.letterSpacing=tracking+'px';
   if(accent)paintAccent(x+paint.measureText(text.slice(0,-1)).width,paint.measureText('.').width);
   paint.fillText(text,x,baseline);
  }else{
   const chars=Array.from(text);
   for(const [index,char] of chars.entries()){
    const advance=paint.measureText(char).width;
    if(accent&&index===chars.length-1)paintAccent(x,advance);
    paint.fillText(char,x,baseline);
    x+=advance+tracking;
   }
  }
  tiles=makeTiles(width,height);drawStatic();sync();
 }
 function apply(next,{persist=false}={}){
  if(!choices.includes(next))next='grotesk';const changed=next!==variant;variant=next;document.body.dataset.typography=variant;
  document.querySelectorAll('[data-type-choice]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.typeChoice===variant)));
  $('typeNote').textContent=notes[variant];
  if(persist){const link=new URL(location.href);link.searchParams.set('type',variant);history.replaceState(null,'',link);const state=api.getState();api.setPresentation({...state.presentation,typography:{...state.presentation.typography,variant}});}
  if(changed||!texture)buildTexture();else sync();
 }
 document.querySelectorAll('[data-type-choice]').forEach(button=>button.addEventListener('click',()=>apply(button.dataset.typeChoice,{persist:true})));
 heading.addEventListener('pointerenter',()=>{targetStrength=1;sync()},{passive:true});heading.addEventListener('pointermove',e=>{const box=heading.getBoundingClientRect();pointerX=clamp((e.clientX-box.left)/Math.max(1,box.width),0,1);pointerY=clamp((e.clientY-box.top)/Math.max(1,box.height),0,1);targetStrength=e.pointerType==='touch'?.65:1;sync()},{passive:true});
 for(const event of ['pointerleave','pointercancel'])heading.addEventListener(event,()=>{targetStrength=.6;sync()},{passive:true});
 document.addEventListener('jl:view-change',()=>{if(document.body.dataset.view==='projects')buildTexture();else sync()});
 document.addEventListener('jl:project-title-change',buildTexture);
 document.addEventListener('jl:archive-change',sync);document.addEventListener('jl:presentation-change',()=>apply(preferred()));document.addEventListener('visibilitychange',sync);reduced.addEventListener('change',sync);$('motionToggle').addEventListener('click',sync);
 document.addEventListener('jl:opening-start',sync);document.addEventListener('jl:opening-end',sync);
 for(const dialog of document.querySelectorAll('dialog'))dialog.addEventListener('close',sync);
 document.addEventListener('click',()=>{if(document.querySelector('dialog[open]'))sync()});
 if('ResizeObserver' in window)new ResizeObserver(()=>{if(resizeFrame)cancelAnimationFrame(resizeFrame);resizeFrame=requestAnimationFrame(()=>{resizeFrame=0;if(document.body.dataset.view==='projects')buildTexture()})}).observe(heading);else addEventListener('resize',buildTexture,{passive:true});
 if('IntersectionObserver' in window)new IntersectionObserver(entries=>{visible=entries.some(entry=>entry.isIntersecting);sync()},{threshold:.01}).observe(heading);
 apply(preferred());
})();
